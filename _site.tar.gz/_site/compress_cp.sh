tar czvf _site.tar.gz _site/
scp _site.tar.gz wejiang@web-login.inf.ethz.ch:~/
